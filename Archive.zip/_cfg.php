<?php

// I'm including all paths in one variable so they can be
// easily imported into functions if needed
$project_paths = array(
  'main_project_root' => $_SERVER['DOCUMENT_ROOT'] ,
  'public_path' => ''
);


