<?php

include($_SERVER['DOCUMENT_ROOT'] . '/_cfg.php');
include( $project_paths['main_project_root'] . '/functions.php');

?>

<?php

/*  PAGE INFO ============ */

$page_title = "template - don't use";

/*  ---------------------- */

?>

<?php echo site_header(); ?>



<?php echo site_footer(); ?>
