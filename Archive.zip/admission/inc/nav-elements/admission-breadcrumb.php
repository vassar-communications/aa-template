<li class="breadcrumb-item"><a href="/"><?php icon('home'); ?> Home</a></li>
<li class="breadcrumb-item"><a href="/admission">Admission</a></li>