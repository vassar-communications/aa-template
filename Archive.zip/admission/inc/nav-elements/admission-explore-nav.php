<li class="active"><a href="/admission/explore/academics">Academics</a></li>
<li class=""><a href="/admission/explore/campus">Campus</a></li>
<li class=""><a href="/admission/explore/student-life">Student Life</a></li>
<li class=""><a href="/admission/explore/diversity-inclusion">Diversity &amp; Inclusion</a></li>
<li class=""><a href="/admission/explore/outcomes">Outcomes</a></li>
<li class=""><a href="/admission/explore/poughkeepsie-hudson-valley">Poughkeepsie &amp; The Hudson Valley</a></li>
