<li class="animation-item"><a href="/admission/financial-aid/apply">Applying for Aid</a></li>
<li class="animation-item"><a href="/admission/financial-aid/aid-calculators">Aid Calculators</a></li>
<li class="animation-item"><a href="/admission/financial-aid/types-of-aid">Types of Aid</a></li>
<li class="animation-item"><a href="/admission/financial-aid/forms">Forms & Resources</a></li>
<li class="animation-item"><a href="/admission/financial-aid/tuition">Tuition & Fees</a></li>