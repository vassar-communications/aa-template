<li class="animation-item active"><a href="/admission/visit/in-person">In-Person Visits</a></li>
<li class="animation-item"><a href="/admission/visit/virtual-programs">Virtual Programs</a></li>
<li class="animation-item"><a href="/admission/visit/group-visits">Group Visits</a></li>
