<li class="animation-item"><a href="/admission/apply/how-to-apply">How to Apply</a></li>
<li class="animation-item"><a href="/admission/apply/first-year-applicants">First-Year Applicants</a></li>
<li class="animation-item"><a href="/admission/apply/transfer">Transfer Applicants</a></li>
<li class="animation-item"><a href="/admission/apply/international">International Applicants</a></li>
<li class="animation-item"><a href="/admission/apply/veterans">Information for Veterans</a></li>
<li class="animation-item"><a href="/admission/apply/questbridge">QuestBridge Students</a></li>
<li class="animation-item"><a href="/admission/apply/financial-aid">Financial Aid</a></li>