<li class="animation-item"><a href="/admission/explore/">Explore Vassar</a></li>
<li class="animation-item"><a href="/admission/apply/">Apply</a></li>
<li class="animation-item"><a href="/admission/visit/">Visit Campus</a></li>
<li class="animation-item"><a href="/admission/financial-aid/">Financial Aid</a></li>
<li class="animation-item"><a href="/admission/quick-facts/">Quick Facts</a></li>
<li class="animation-item"><a href="/admission/connect/">Connect</a></li>
