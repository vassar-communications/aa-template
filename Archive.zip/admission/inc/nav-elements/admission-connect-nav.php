<li class="animation-item"><a href="/admission/connect">Contact Us</a></li>
<li class="animation-item"><a href="#">First-Year Applicants</a></li>
<li class="animation-item"><a href="/admission/connect/meet-the-students">Meet the Students</a></li>
<li class="animation-item"><a href="/admission/connect/for-counselors">For Counselors</a></li>