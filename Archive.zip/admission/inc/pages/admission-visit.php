<div class="g-col column ">
    <a class="card mb-4" href="/admission/visit">
        <div class="card-body">
            <h4 class="card-title">Visit Campus</h4>
            <div class="card-text">
                <p>Get to know our vibrant community first-hand and learn more about the Vassar experience.</p>
                <i class="bi bi-plus"></i>
            </div>
        </div>
    </a>
</div>