<div class="g-col column ">
    <a class="card mb-4" href="/admission/apply/transfer">
        <div class="card-body">
            <h4 class="card-title">Transfer Applicants</h4>
            <div class="card-text">
                <p>Students who have earned a high school diploma or GED and have enrolled at a college or university are welcome to apply as a transfer applicant.</p>
                <i class="bi bi-plus"></i>
            </div>
        </div>
    </a>
</div>