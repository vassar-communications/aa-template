<div class="g-col column ">
    <a class="card mb-4" href="/admission/apply/transfer">
        <div class="card-body">
            <h4 class="card-title">Applying to Vassar</h4>
            <div class="card-text">
                <p>Learn more about Vassar's application requirements and important deadlines.</p>
                <i class="bi bi-plus"></i>
            </div>
        </div>
    </a>
</div>